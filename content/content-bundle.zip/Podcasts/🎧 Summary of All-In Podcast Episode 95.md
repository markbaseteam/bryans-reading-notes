# 🎧 Summary of All-In Podcast Episode 95
## ⚡️ Europe's Winter Energy Crisis
- Russia has cut off natural gas supplies to Europe as a result of the Russia-Ukraine conflict. The result:
	- The price of gas has become 10 times higher than the average cost of the past 10 years (Source: [Goldman Sachs Report](https://www.goldmansachs.com/insights/pages/europe-energy-crisis-is-at-a-tipping-point.html))
	- Cost of food and heating homes has increased
	- This could cascade into the buying power of European currencies to diminish, costs to import goods and services to inflate, and economies being negatively impacted
- Many European leaders are still determined to stand up against Russia, but a compromise may need to be negotiated if the war further worsens the lives of their own citizens

## 💰 Kim Kardashian launches her own private equity firm
- Her firm SKKY Partners will invest in consumer and media businesses. 
- The rise of influencers, creators and individuals as a predictor of the firm's success:
	- Distribution is the number one problem for all consumer goods and services. Costs of advertising on social media has increased significantly resulting in worse unit economics for direct-to-consumer (DTC) businesses. Content marketing has become an essential marketing strategy as influencers can directly distribute goods to their audience at little cost.
	- Every company needs to create content to differentiate themselves.

